/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.editorConfig = function( config ) {
    // Define changes to default configuration here.
    // For complete reference see:
    // http://docs.ckeditor.com/#!/api/CKEDITOR.config

    CKEDITOR.config.enterMode = 2;
    CKEDITOR.config.height = '280px';
    CKEDITOR.config.resize_enabled = false;

    //---------------
    CKEDITOR.lang.medialanguages=['en', 'ja', 'zh-cn'];
    CKEDITOR.lang.languages={"en":1,"ja":1,"zh-cn":1};
    if (desknets.Resource.code == 'zh_CN') {
        CKEDITOR.config.language = 'zh-cn';
    }
    else {
        CKEDITOR.config.language = desknets.Resource.code;
    }
    //---------------

    CKEDITOR.config.toolbar = [
        ['FontSize'], ['TextColor','BGColor'], ['Bold','Italic','Underline','Strike','HorizontalRule'],
        ['JustifyLeft','JustifyCenter','JustifyRight'], ['NumberedList','BulletedList'], ['Link','Unlink'], ['ImgEditor'], '/',
        ['Image','Media','Preview'], ['Source'], ['Maximize'], ['Find','Replace'], ['Undo','Redo'], ['Table']];

    config.removeDialogTabs = 'image:advanced;link:advanced;link';
    config.extraPlugins = 'media';

    config.colorButton_colorsPerRow = 10; 
    config.colorButton_colors =
        'D32F2F,C2185B,E64A19,FFA000,388E3C,0288D1,303F9F,512DA8,455A64,000000,' +
        'F44336,E91E63,FF5722,FFC107,4CAF50,03A9F4,3F51B5,673AB7,607D8B,9E9E9E,' +
        'E57373,F06292,FF8A65,FFD54F,81C784,4FC3F7,7986CB,9575CD,90A4AE,E0E0E0,' +
        'FFCDD2,F8BBD0,FFCCBC,FFECB3,C8E6C9,B3E5FC,C5CAE9,D1C4E9,CFD8DC,F5F5F5,' +
        'FFEBEE,FCE4EC,FBE9E7,FFF8E1,E8F5E9,E1F5FE,E8EAF6,EDE7F6,ECEFF1,FAFAFA,' +
        'FFFCFC,FEF3F7,FDF6F6,FFFCF2,F4FAF4,F1FAFF,F4F5FB,F6F3FB,F6F7F8,FFFFFF';
    config.extraAllowedContent = '*[type,title]{*};pre;';
    config.disallowedContent = '*{behavior}';
};

CKEDITOR.dom.window.prototype.getViewPaneSize = function() {
  var a = this.$.document, f = (a.compatMode == "CSS1Compat" && !desknets.browser.tablet);
  return {
      width: (f ? a.documentElement.clientWidth : a.body.clientWidth) || 0,
      height: (f ? a.documentElement.clientHeight : a.body.clientHeight) || 0
  }
}

CKEDITOR.on('dialogDefinition', function(event) { 
    // ダイアログの項目を取得する
    function getDefItem(def, id) {
        var i, item = def.id == id ? def : null, propsSub = ['children', 'contents', 'elements'], subDefs = [];
        if (!item) {
            for (i = 0; i < propsSub.length; i++) {
                if (def[propsSub[i]] instanceof Array) {
                    subDefs = def[propsSub[i]];
                    break;
                }
            }

            for (i = 0; i < subDefs.length; i++) {
                item = getDefItem(subDefs[i], id);
                if (!!item) {
                    break;
                }
            }
        }

        return item;
    }

    var dialog = event.data;
    if (['table'].indexOf(dialog.name) >= 0) {
        // 表: 枠線の幅入力欄を消す。
        dialog.definition.onShow = function() {
            var text = this.getContentElement('info', 'txtBorder');
            text.disable();
        }
    } else if  (dialog.name == 'link') {
        // ハイパーリンク: URL, E-Mail以外のリンクタイプを消す。
        var linkType = getDefItem(dialog.definition, 'linkType');
        if (!!linkType && linkType.items instanceof Array) {
            linkType.items = linkType.items.filter(function (item) { return ['url', 'email'].indexOf(item[1]) >= 0; });
        }
        // ハイパーリンク: ターゲット「ポップアップウィンドウ」を消す。
        var linkTargetType = getDefItem(dialog.definition, 'linkTargetType');
        if (!!linkTargetType && linkTargetType.items instanceof Array) {
            linkTargetType.items = linkTargetType.items.filter(function (item) { return 'popup' != item[1]; });
        }
        // ハイパーリンク: プロトコルを「http」、「https」、「ftp」、「file」にする。
        var protocol = getDefItem(dialog.definition, 'protocol');
        var url = getDefItem(dialog.definition, 'url');
        if (!!protocol && !!url && protocol.items instanceof Array) {
            var protocolArr = [['http://', 'http://'], ['https://', 'https://'], ['ftp://', 'ftp://'], ['file://', 'file://']];
            protocolArr.push(protocol.items[protocol.items.length - 1]);
            protocol.items = protocolArr;
            
            url.onKeyUp = function (){
                this.allowOnChange = false;
                var urlValue = this.getValue(), matches = urlValue.match(/^([a-z]+:\/\/)./i);
                if (!!matches && protocolArr.some(function (item) { return item[1] == matches[1]; })) {
                    this.getDialog().getContentElement('info', 'protocol').setValue(matches[1]);
                    this.setValue(urlValue.substr(matches[1].length));                    
                }
                this.allowOnChange = true;
            };
        }
    }
});

CKEDITOR.on( 'instanceReady', function( ev ){
    var editor = ev.editor;
    // ソース表示中、最大化中は「ファイル挿入」できない。
    editor.on( 'beforeCommandExec', function( ev ){
        if (ev.data.name == 'source') {
            var $button = $('.cke_button__imgeditor');
            if ($button.length > 0) {
                $button.toggleClass('sourceview');
            }
        }
        else if (ev.data.name == 'maximize') {
            var $button = $('.cke_button__imgeditor');
            if ($button.length > 0) {
                $button.toggleClass('maximizeview');
            }
        }
    });
});
