#!/bin/sh

export LD_LIBRARY_PATH=/var/www/cgi-bin/dnpwml/lib
/var/www/cgi-bin/dnpwml/dnpscheduler /var/www/cgi-bin/dnpwml 5
