//var neo = {};
(function($) {
//neo.Resource = {};
/**
 * Ajax通信の文言
 *
 * @class Ajax通信の文言
 */
DNNEO.neo.Resource.ajax = {
    '400_errorMessage' : 'W:この処理は完了しているか手順を踏まえていない可能性があります。 作業を中断し、最初からやり直してください。',
// ブラウザが勝手に認証ダイアログを表示するので403に統括    "401_errorMessage" : "W:認証できませんでした。再度ログインしてください。",
    '403_errorMessage' : 'W:要求された処理にアクセスできません。<br/>権限の変更が発生したかセッションが切れた可能性があります。作業を中断し、最初からやり直してください。',
    '404_errorMessage' : 'URLが間違っている可能性があります。',
    '408_errorMessage' : 'W:データベースサーバーが混み合っています。しばらく待ってから再度実行してください。',
    '409_errorMessage' : 'データベースが停止しているまたは作業領域にアクセス権がない等、サーバーで異常が発生しました。システム管理者にご連絡ください。',

    '500_errorMessage' : 'サーバーで異常が発生しました。システム管理者にご連絡ください。',

    // Webサーバーの接続制限に達した
    '503_errorMessage' : 'W:サーバーが混み合っています。しばらく待ってから再度実行してください。',

    '504_errorMessage' : 'サーバーでタイムアウトが発生しました。',

    // Webサーバーが停止しているときに発生
    'errorMessage' : 'サーバーが停止しているか、ネットワークが込み合っている可能性があります。[{{status}}]'
};
})(jQuery);
/// <reference path="/njres/js/extlibs/jquery-1.6.3-vsdoc.js" />
/// <reference path="/njres/js/extlibs/jquery-ui-1.8.16.custom.js" />

//var desknets = {};

/**
 *  共通系文言
 *
 * @class 共通系文言
 */
desknets.Resource = {
      'code': 'ja_JP'
/*
ダイアログのタイトル
*/
    , 'errorDefaultTitle'   : 'エラー'
    , 'warnDefaultTitle'    : '警告'
    , 'confirmDefaultTitle' : '確認'
    , 'messageDefaultTitle' : 'メッセージ'

/*
ダイアログのボタン
*/
    , 'CloseButtonLabel': '閉じる' // 参照系ダイアログの確認ボタン
    , 'OKButtonLabel': 'OK' // 選択、変更系ダイアログの決定ボタン
    , 'CancelButtonLabel': 'キャンセル' // 選択、変更系ダイアログの取り消しボタン
    , 'ConfOKButtonLabel': 'はい' // 確認ダイアログの肯定ボタン
    , 'ConfCancelButtonLabel': 'いいえ' // 確認ダイアログの否定ボタン

/**
 よく使う文言
 */
   , 'closeLabel': '閉じる'
   , 'abortLabel' : '中止'
   , 'attachLabel':'添付'

/**
 添付
 */
   , 'attachTitle': '添付ファイル'
};

(function($) {
/**
 *  メッセージリソース
 *  記述方法
 *  '機能IDXXX' : 'レベル:XXXXXXXXXXXXXXXXXXXXXXXXXXX'
 *  機能ID＝sch,todo等
 *  レベル＝E:エラー,W:警告,M:メッセージ
 *
 * @class desknets.Resuorc.Message
 */
desknets.Resource.Message = {
//-----------------------------------------------------------
// 共通
//-----------------------------------------------------------
    // , 'com_copy_attachsize_over': 'M:添付ファイルのサイズが制限を超えたため、添付は複写しませんでした。'
    // , 'com_copy_attachs_missing': 'M:添付ファイルのコピーに失敗しました。<br />人為的もしくはアンチウィルス等の外部プログラムに削除された可能性があります。添付ファイルを再度選択してください。'
//-----------------------------------------------------------
// 検索共通
//-----------------------------------------------------------
      'com_attachlist_confirm_one': '選択したファイルを解除します。よろしいですか？'
    , 'com_attachlist_confirm_all': 'すべてのファイルを解除します。よろしいですか？'
//-----------------------------------------------------------
// 添付ファイル関連
//-----------------------------------------------------------
    , 'att_total_size_over':     'W:アップロード可能な合計サイズを超えています。合計サイズ({{total}})／アップロード可能サイズ({{limit}})'
    , 'att_filesize_zero':       'W:０バイトのファイルはアップロードできません。({{filenames}})'
    , 'att_overlap_file_single': 'ファイル名が重複しています。上書きしますか？({{filenames}})'
    , 'att_overlap_file_multi':  'ファイル名が重複しているファイルが{{num}}個あります。上書きしますか？({{filenames}})'
    , 'att_other_files':         '．．．他({{num}}ファイル)'
    , 'att_drop_max_over':       'W:ドロップ可能なファイル数を超えています。{{num}}個指定されました。最大は{{max}}個です'
    , 'att_illegal_filename':    'W:指定されたファイルのファイル名が無効です。'
    , 'att_file_select':         'W:アップロードするファイルを指定してください。'
    , 'att_detach_all':          'すべてのファイルを解除します。よろしいですか？'
    , 'att_close_dialog':        '指定したファイルはアップロードされません。よろしいですか？'
    , 'att_close_clear':         'アップロードしたファイルを取り消しますか？'
    , 'att_del_confirm':         '「{{filenames}}」を解除します。よろしいですか？'
    , 'att_network_err':         'サーバーの接続に失敗しました。'
    , 'att_upload_now':          'アップロード中です。'
    , 'att_flash_reject_cancel_single': 'W:上書きしたファイル「{{filenames}}」は取り消されませんでした。'
    , 'att_flash_reject_cancel_multi' : 'W:上書きしたファイル「{{filenames}}」他({{num}}ファイル)は取り消されませんでした。'
    , 'att_flash_reject_delete'       : 'W:上書きしたファイル「{{filenames}}」は削除できません。'
};

})(jQuery);
/// <reference path="/njres/lang/ja_JP/js/resource.js.src/002resource.js" />

(function($) {
/**
 * 添付ファイル関連
 */
desknets.Resource.attach = {
    // 処理中表示で100%の場合、プログレスバーに表示する文言
  'saveMsg': '<span class="co-pop-tp-file-save">保存中です...</span>'
  , 'saveMsgIE': '保存中です...'
    // IEでアップロード中にプログレスバーへ表示しておく文言
  , 'uploadMsg': '保存中です...'
    // ドロップ可能な最大数を表示
  , 'dropMaxMsg': 'ここにファイルをドロップ（最大{{maxdrop}}個）するか'
    // Flashに渡すラベル
  , 'saveLabel': '保存中です...'
  , 'deleteLabel': '解除'
  , 'deleteAllLabel': 'すべての選択を解除'
  , 'flashChangeMsg': '<p class="co-msg">※&nbsp;複数添付機能の添付ボタンに戻す場合は、アップロード方法を切り替えてください。→<a href="#" class="co-pop-tp-flash-mode-change-btn">切替</a></p>'
  , 'flashChangeMsgNormal': '<p class="co-msg">※&nbsp;添付ボタンが正常に動作しない場合は、アップロード方法を切り替えてください。→<a href="#" class="co-pop-tp-flash-mode-change-btn">切替</a></p>'
  , 'flashDownloadMsg': '<p class="co-msg"><FONT color="red">※&nbsp;FlashPlayerがインストールされていません。FlashPlayerをインストールしてください。</FONT><a href="http://www.adobe.com/go/getflashplayer" target="flash"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" /></a></p>'

  , 'cancelAllUploadLabel': '全アップロード中止'
  , 'dropHereLabel': 'ここにファイルをドロップするか、'
  , 'clickFileSelectLabel': 'クリックしてファイルを選択してください。'
  , 'selectFromButtonLabel': '添付ボタンからファイルを選択してください。'
  , 'attachLabel': '添付'
  , 'releaseLabel': '選択を解除'
  , 'deleteLabel': '削除'
  , 'fileUploadLabel': 'ファイルをアップロード'
};

})(jQuery);
