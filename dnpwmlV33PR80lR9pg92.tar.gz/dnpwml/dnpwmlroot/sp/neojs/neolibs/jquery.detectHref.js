(function($){
var defaultOptions = {
	convertMail: true,
	convertPhone: false,
	convertURL: true,
	mailFilter: function(aElement) {},
	phoneFilter: function(aElement) {},
	urlTarget: "_blank",
	urlFilter: function(aElement) {},
};

/**
 * @class
 * 静的フィールドとメソッド
 */
// $.プラグイン名 = { ローカライズ用初期値など };

/**
 * @class
 * 公開メソッド群
 */
var methods = {
	/**
	 * 要素の構築する。
	 * 
	 * @param {Object} options [IN]:オプション
	 */
	init: function(options) {
		this.each(function(){
			_methods.convertElement(this, options);
		});
	},

	// プラグインメソッド
	// メソッド名:function(引数) {},
};

/**
 * @class
 * 非公開メソッド群
 */
var _methods = {
	/**
	 * 要素内を変換する。
	 * 
	 * @param {Node}   element [IN]:DOM ノード
	 * @param {Object} options [IN]:オプション
	 */
	convertElement: function(element, options) {
		var nChildren = element.childNodes.length;
		for (var i = nChildren - 1;i >= 0 ;i--) {
			// A以外の要素
			if (element.childNodes[i].nodeType == 1 && element.childNodes[i].tagName != "A") {
				_methods.convertElement(element.childNodes[i], options);
			// 文字ノード
			} else if (element.childNodes[i].nodeType == 3 || element.childNodes[i].nodeType == 4) {
				_methods.convertText(element.childNodes[i], options);
			}
		}
	},

	/**
	 * 文字ノードを変換する。
	 * 
	 * @param {Node}   textNode [IN]:DOM ノード
	 * @param {Object} options  [IN]:オプション
	 */
	convertText: function(textNode, options) {
		var tokens = _methods.splitText(textNode.data, options);
		$.each(tokens, function(index, token){
			_methods.appendTokenToNode(token, textNode, options);
		});
		textNode.parentNode.removeChild(textNode);
	},

	/**
	 * 文字列をトークン列に分割する。
	 * 
	 * @param {String}  text    [IN]:分割対象文字列
	 * @param {Object}  options [IN]:オプション
	 * @return {Array} トークン列
	 */
	splitText: function(text, options) {
		var urlPattern = /(https?:\/\/[\w%_!~\-\.\*\(\);:@&=\/\?\+\$\,]+)/g;
		var mailPattern = /([\w\.\-_]+@[\w\-\._]+\w)/g;
		var phonePattern = /(0\d+\-\d+\-\d{4})/g;
		var tokens = [{type: "text", content: text}];
		if (options.convertURL) {
			tokens = _methods.splitTokensFromTokens(tokens, "url", urlPattern);
		}
		if (options.convertMail) {
			tokens = _methods.splitTokensFromTokens(tokens, "mail", mailPattern);
		}
		if (options.convertPhone) {
			tokens = _methods.splitTokensFromTokens(tokens, "phone", phonePattern);
		}

		return tokens;
	},

	/**
	 * トークン列を正規表現で分割したトークン列を取得する。
	 * 
	 * @param {Array}   tokens   [IN]:トークン列
	 * @param {String}  typeName [IN]:分割種別の名前
	 * @param {RegExp}  pattern  [IN]:正規表現(URL、メールなど)
	 * @return {Array} 分割後のトークン列
	 */
	splitTokensFromTokens: function(tokens, typeName, pattern) {
		var newTokens = [];
		$.each(tokens, function(i, token) {
			if (token.type == "text") {
				var thisToken = _methods.getTokensFromText(token.content, typeName, pattern);
				$.merge(newTokens, thisToken);
			} else {
				newTokens.push(token);
			}
		});
		return newTokens;
	},

	/**
	 * 文字列を正規表現で分割したトークン列を取得する。
	 * 
	 * @param {String}  text     [IN]:分割対象文字列
	 * @param {String}  typeName [IN]:分割種別の名前
	 * @param {RegExp}  pattern  [IN]:正規表現(URL、メールなど)
	 * @return {Array} トークン列
	 */
	getTokensFromText: function(text, typeName, pattern) {
		var tokens = [];
		var splitted = text.split(pattern);
		$.each(splitted, function(i, text) {
			if (i % 2 == 0) {
				tokens.push({type: "text", content: text});
			} else {
				tokens.push({type: typeName, content: text});
			}
		});

		return tokens;
	},

	/**
	 * ノードにトークンを追加する。
	 * 
	 * @param {Object} token   [IN]:トークン
	 * @param {Node}   textNode [IN]:DOM ノード
	 * @param {Object} options  [IN]:オプション
	 */
	appendTokenToNode: function(token, textNode, options){
		if (token.type == "text"){
			// テキストノードの追加
			var node = document.createTextNode(token.content);
			textNode.parentNode.insertBefore(node, textNode);
		} else if (token.type == "url"){
			// A要素(URLメールアドレス)の追加
			var node = _methods.insertElementToNode(
				textNode, token.content, token.content, options.urlFilter);
			node.target = options.urlTarget;
		} else if (token.type == "mail"){
			// A要素(メールアドレス)の追加
			var href = "mailto:" + token.content;
			_methods.insertElementToNode(
				textNode, token.content, href, options.mailFilter);
		} else if (token.type == "phone"){
			// A要素(電話番号)の追加
			var href = "tel:" + token.content.replace(/[^0-9]/g, "");
			_methods.insertElementToNode(
				textNode, token.content, href, options.phoneFilter);
		}
	},

	/**
	 * ノードに要素を挿入する。
	 * 
	 * @param {Node}     node   [IN]:挿入基準ノード 
	 * @param {String}   text   [IN]:URL、メールアドレス
	 * @param {String}   href   [IN]:hrefの内容
	 * @param {Function} filter [IN]:フィルター関数
	 * @return {Element} 作成したA要素
	 */
	insertElementToNode: function(node, text, href, filter){
		var aElement = document.createElement("A");
		aElement.href = href;
		node.parentNode.insertBefore(aElement, node);
		$(aElement).text(text);
		filter(aElement);
		return aElement;
	}
};

$.fn.detectHref = function(methodNameOrOptions){
	var isMethodName = typeof(methodNameOrOptions) == "string";
	// メソッド呼び出し
	if (isMethodName) {
		var methodArgs = Array.prototype.slice.call(arguments, 1);
		return methods[methodNameOrOptions].apply(this, methodArgs);
	}

	// プラグイン処理
	var customOptions = (typeof(methodNameOrOptions) == "object") ? methodNameOrOptions : {};
	var options = $.extend({}, defaultOptions, customOptions);
	return methods.init.apply( this, [options]);
};

})(jQuery);
