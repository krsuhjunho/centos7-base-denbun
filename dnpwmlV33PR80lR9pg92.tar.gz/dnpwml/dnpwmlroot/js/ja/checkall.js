function checkUserAgentVersion() {
      var res = -1;
      var p = navigator.userAgent.indexOf("Mozilla/");

      if (p > -1) {
          p = p + 8;
          res = navigator.userAgent.substring(p, p+1);
      }

      if (res == -1) {
          if (navigator.userAgent.indexOf("MSIE") != -1) {
              res = 1;
          } else {
              p = navigator.userAgent.indexOf("Opera");
              if (p > -1) {
                  p = p + 6;
                  res = navigator.userAgent.substring(p, p+1);
              }
              else {
                  res = 0;
              }
          }
      }

      return res;
}

if (checkUserAgentVersion() >= 3) {
    var imgoff = new Image();
    imgoff.src = '/dnpwmlroot/img/config/ic_all_check_on.gif';
    var imgon = new Image();
    imgon.src = '/dnpwmlroot/img/config/ic_all_check.gif';
}

function changeImage(img) {
	if (checkUserAgentVersion() >= 3 && img) {
        if(img != '') {
		    document.check.src = img.src;
        }
	}
}

function CheckBoxChecked() {
    if (checkUserAgentVersion() >= 3) {
        if(document._form.all.value == 1) {
            document._form.all.value = '';
            changeImage(imgon);
        }
        else {
            document._form.all.value = '1';
            changeImage(imgoff);
        }
    }

    for (i_cnt=0; i_cnt<document._form.elements.length; i_cnt++) {
  
        if (document._form.elements[i_cnt].type=='checkbox' && document._form.elements[i_cnt].name=='id') {
            document._form.elements[i_cnt].checked = document._form.all.value;
        }
    }
}