CKEDITOR.plugins.add('media', {
    icons: 'media',
    lang: CKEDITOR.lang.medialanguages, // BTMANTIS0026457_V30R11

    types: {},
    baseurl: '', // BTMANTIS0026581_V30R12

    /**
     * エディターを初期化する。
     *
     * @param {CKEDITOR.editor} editor エディター
     */
    init: function(editor) {
        var self = this, lm = editor.lang.media;
        this.types['video'] = {'label': lm.typeVideo, 'tagName': 'video', 'attrs': {'controls': 'controls'}};
        this.types['audio'] = {'label': lm.typeAudio, 'tagName': 'audio', 'attrs': {'controls': 'controls'}, 'noSize': true};
        this.types['wmedia'] = {'label': lm.typeWMedia, 'tagName': 'embed', 'attrs': {'type': 'application/x-mplayer2'}};
        this.types['rplayer'] = {'label': lm.typeReal, 'tagName': 'embed', 'attrs': {'type': 'audio/x-pn-realaudio-plugin'}};
        this.types['qt'] = {'label': lm.typeQt,  'tagName': 'embed', 'attrs': {'type': 'video/quicktime'}};
        this.types['flash'] = {'label': lm.typeFlash, 'tagName': 'embed', 'attrs': {'type': 'application/x-shockwave-flash'}};
//        this.types['shockwave'] = {'label': lm.typeShockwave, 'tagName': 'embed', 'attrs': {'type': 'application/x-director'}};
        this.types['iframe'] = {'label': lm.typeIframe, 'tagName': 'iframe'};

        editor.addCommand('media', new CKEDITOR.dialogCommand('mediaDialog', {
            'allowedContent': 'video[src,width,height];audio[src];iframe[src,width,height];object[data,type,width,height];embed[src,type,width,height]'
        }));
        editor.ui.addButton('Media', {'label': lm.menu, 'command': 'media', 'toolbar': 'insert'});
        editor.addContentsCss(this.path + 'styles/media.css');
        CKEDITOR.dialog.add( 'mediaDialog', this.path + 'dialogs/media.js' );

        if ( editor.contextMenu ) {
            editor.addMenuGroup('mediaGroup');
            editor.addMenuItem( 'mediaItem', {'label': lm.menuItemTitle, 'icon': this.path + 'icons/media.png', 'command': 'media', 'group': 'mediaGroup'});
            editor.contextMenu.addListener( function(element) {
                if (String(element.getAttribute('data-cke-real-element-type')).indexOf('media') == 0) {
                    return {'mediaItem': CKEDITOR.TRISTATE_OFF};
                }
            });
        }

        // BTMANTIS0026581_V30R12 START
        var sUrl = document.URL;
        var iIndex = 0;
        var sBaseUrl = '';

        // query以下を除去
        iIndex = sUrl.indexOf("?");
        if (iIndex > 0) {
            sUrl = sUrl.substring(0, iIndex);
        }

        // 基本URLを設定する。
        iIndex = sUrl.lastIndexOf('/');
        if (iIndex >= 0) {
            sBaseUrl = sUrl.substring(0, iIndex + 1);
        }
        else {
            sBaseUrl = sUrl;
        }

        this.baseurl = sBaseUrl;
        // BTMANTIS0026581_V30R12 END
        ['mode', 'dataReady'].forEach(function (eName){
        editor.on(eName, function(e) {
            if (editor.mode == 'wysiwyg') {
                self.convertMediaElements(editor);
            }
        });			
		});

        editor.on('mode', function(e) {
            if (editor.mode == 'wysiwyg') {
                self.convertMediaElements(editor);
            }
        });
    },

    /**
     * エディターのメディア要素を置き換え要素に変換する。
     *
     * @param {CKEDITOR.editor} editor エディター
     */
    convertMediaElements: function(editor) {
        var tagNames = ['video', 'audio', 'iframe', 'embed', 'object'], nsNames = [null, null, null, 'cke', 'cke'];
        for (var iTag = 0; iTag < tagNames.length; iTag++) {
            var elements = editor.document.getElementsByTag(tagNames[iTag], nsNames[iTag]);
            var nItems = elements.count();
            for (var iElm = nItems - 1; iElm >= 0; iElm--) {
                var element = elements.getItem(iElm);
                var properties = this.getPropertiesFromElement(element);
                var elFake = this.createMediaElement(editor, properties, true);
                // embedの親がobjectの場合、親と入れ替える。
                var elParent = element.getParent(), name = elParent.getName();
                elFake.replace(CKEDITOR.tools.indexOf(tagNames, name) >= 0 ? elParent : element);
            }
        }
    },

    /**
     * 要素からプロパティを取得する。
     *
     * @param {CKEDITOR.dom.element} element 対象要素
     * @returns {String} .url URL
     * @returns {String} .type 種類
     * @returns {String} .width 幅
     * @returns {String} .height 高さ
     */
    getPropertiesFromElement: function(element) {
        var props = { 'type': 'iframe' };
        var name = element.getName(), mime = element.getAttribute('type');
        if (name == 'video' || name == 'audio' || name == 'iframe') {
            props = { 'type': name };
        } else {
            for (var key in this.types) {
                if ((!!this.types[key].attrs && this.types[key].attrs.type == mime) || this.types[key].embedType == mime) {
                    props = { 'type': key };
                    break;
                }
            }
        }
        props.url = element.getAttribute(name == 'object' ? 'data' : 'src');
        // BTMANTIS0026389_V30R11 START 高さが未設定の場合はそのままとする
        // props.width = element.getAttribute('width') || 320;
        // props.height = element.getAttribute('height') || 240;
        props.width = element.getAttribute('width') || '';
        props.height = element.getAttribute('height') || '';
        // BTMANTIS0026389_V30R11 END
        return props;
    },

    /**
     * メディア用の要素を作成する。
     *
     * @param {CKEDITOR.editor} editor エディター
     * @param {String} properties.url URL
     * @param {String} properties.type 種類
     * @param {String} properties.width 幅
     * @param {String} properties.height 高さ
     * @param {Boolean} isFake trueならエディター置き換え用にする
     * @returns {CKEDITOR.dom.element}
     */
    createMediaElement: function(editor, properties, isFake) {
        var element = null, detail = this.types[properties.type || ''];
        if (!!detail && !!properties.url) {
            element = editor.document.createElement(detail.tagName);
            // BTMANTIS0026581_V30R12
            if (isFake && !!properties.inputurl) {
                element.setAttribute('src', properties.inputurl);
            }
            else {
                element.setAttribute('src', properties.url);
            }
            // サイズ
            if (!detail.noSize) {
                if (properties.width > 0) {
                    element.setAttribute('width', properties.width);
                }
                if (properties.height > 0) {
                    element.setAttribute('height', properties.height);
                }
            }
            // 他の属性
            if (!!detail.attrs) {
                for (var name in detail.attrs) {
                    element.setAttribute(name, detail.attrs[name]);
                }
            }
            // Editor用
            if (isFake) {
                // BTMANTIS0026722_V30R12 START
                // IE8でメディアのプラグインから、embedタグを設定して、登録すると、登録のデータでsrcとtypeの属性が不正な状態となり、再生ができない。
                // video、audio、iframeは正しく取得できている。
                // 「<embed xxx=xxx yyy=yyy />」 となるタグの場合、ダブルクォートにくくられていない「/」があるとタグが終わりだと認識される。
                if (desknets.browser.msie8
                 && (properties.type == 'wmedia' || properties.type == 'rplayer' || properties.type == 'qt' || properties.type == 'flash')
                ) {
                    // 例 '<embed type="application/x-mplayer2" src="http://xxxx/media/mp4.mp4" height="240" width="320" />';
                    var shtml = '<embed';
                    if (!!detail.attrs) {
                        for (var name in detail.attrs) {
                            shtml = shtml + ' ' + name + '="' + detail.attrs[name] + '"';
                        }
                    }
                    if (properties.width > 0) {
                        shtml = shtml + ' width="' + properties.width + '"';
                    }
                    if (properties.height > 0) {
                        shtml = shtml + ' height="' + properties.height + '"';
                    }
                    if (!!properties.inputurl) {
                        shtml = shtml + ' src="' + properties.inputurl + '" />';
                    }
                    else {
                        shtml = shtml + ' src="' + properties.url + '" />';
                    }

                    element = this.createFakeElementMediaIe8(element, 'co-cke-media-placeholder ' + properties.type, 'media_' + properties.type, !detail.noSize, editor, shtml);
                }
                else {
                    element = editor.createFakeElement(element, 'co-cke-media-placeholder ' + properties.type, 'media_' + properties.type, !detail.noSize);
                }
                // BTMANTIS0026722_V30R12 END
            }
        }

        return element;
    },

    // BTMANTIS0026722_V30R12 START
    createFakeElementMediaIe8 : function( realElement, className, realElementType, isResizable, editor, shtml ) {
		var lang = editor.lang.fakeobjects,
			label = lang[ realElementType ] || lang.unknown;

		var attributes = {
			'class': className,
			'data-cke-realelement': encodeURIComponent( shtml ),
			'data-cke-real-node-type': realElement.type,
			alt: label,
			title: label,
			align: realElement.getAttribute( 'align' ) || ''
		};

		// Do not set "src" on high-contrast so the alt text is displayed. (#8945)
		if ( !CKEDITOR.env.hc )
			attributes.src = CKEDITOR.tools.transparentImageData;

		if ( realElementType )
			attributes[ 'data-cke-real-element-type' ] = realElementType;

		if ( isResizable ) {
			attributes[ 'data-cke-resizable' ] = isResizable;

			var fakeStyle = new CKEDITOR.htmlParser.cssStyle();

			var width = realElement.getAttribute( 'width' ),
				height = realElement.getAttribute( 'height' );

			width && ( fakeStyle.rules.width = CKEDITOR.tools.cssLength( width ) );
			height && ( fakeStyle.rules.height = CKEDITOR.tools.cssLength( height ) );
			fakeStyle.populate( attributes );
		}

		return editor.document.createElement( 'img', { attributes: attributes } );
    },
    // BTMANTIS0026722_V30R12 END



    /**
     * 種類の選択肢を取得する。
     *
     * @returns {Array}
     */
    getTypeSelection: function() {
        var items = [];
        for (var value in this.types) {
            items.push([this.types[value].label, value]);
        }
        return items;
    }
});
