<!--
function ChangeSelect(sel, delchk)
{
	var delval;
	if (sel.checked){
		delval = "";
	}
	else{
		delval = sel.value;
	}
	delchk.value = delval;
}
function AddrLink(area,kind,kno,noall)
{
	if (area != null){
		document._form.jonarea.value = area;
	}
	if (kind != null){
		document._form.kind.value = kind;
	}
	if (kno != null){
		document._form.jonkno.value = kno;
	}
	if (noall != null){
		document._form.noall.value = noall;
	}
	document._form.submit();
}
function AddrPage(row, rowfld)
{
	rowfld.value = row;
	document._form.submit();
}
//--->
