<!--
var w;
function isSupport() {
    var code = 'unknown'; var version = 0;
    var i = navigator.userAgent.indexOf('MSIE');
    if (i >= 0) {
        code = 'MSIE';
        version = parseFloat(navigator.userAgent.substring(i+5, i+9));
    } else {
        i = navigator.userAgent.indexOf('Mozilla/');
        if (i >= 0) {
            code = 'NS';
            version = parseFloat(navigator.userAgent.substring(i+8, i+12));
        }
    }
    var c = code;  var v = version;
    if (((c == 'NS') && (v < 3)) || ((c == 'MSIE') && (v < 4))) return false;
    else return true;
}
function OpenGroup(contid, gid, mode)
{
	document._form.CONST_ID.value = contid;
	document._form.constgid.value = gid;
	document._form.constmd.value = mode;
	document._form.gopen.value = 'open';
	document._form.submit();
}
function ChangeSelect(sel, delchk)
{
	var icnt;
	var delval;
	if (sel.checked){
		delval = "";
	}
	else{
		delval = sel.value;
	}
	delchk.value = delval;
}
function OpenComSelect(cmdselect, cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, cflduid, caddarg, ctempno, inotdel, constnpage, cntempno, cmenucolor, cimageuse, iadmin, cusetdisp, cnodispitem, cnewtarget, ctempname){
	var adrs;
	var addarg;
	var iw;
	var ih;
	var wname;

	if (!isSupport()){
        // "サポートされていないブラウザです。"
	    alert("The browser is not supported.");
		return;
	}

	if (cmdselect == 'constructuser'){
		addarg = '&ukind=1';
	}
	else{
		addarg = '';
	}

	iw = 420;
	ih = 630;
	wname = 'xconstruct';

	if (cmdselect == 'constructuser' || cmdselect == 'constructusers' && igkind != 15){
		iw = 800;
		ih = 550;
		dd = new Date();
		wname = 'xuconst';
		adrs = cgiselect + "?constmd=close&cmd=" + cmdselect + "&const_id=" + constid + "&bcginame=" + cginame + "&constbpage=" + cpage + "&gkind=" + igkind + "&uconnow=" + dd.getTime();
	}
	else{
		adrs = cgiselect + "?gconstruct=1&constmd=close&cmd=" + cmdselect + "&const_id=" + constid + "&bcginame=" + cginame + "&constbpage=" + cpage + "&gkind=" + igkind;
	}
	if (clocalall != null && clocalall.length != 0){
		adrs = adrs + "&localall=" + clocalall;
	}
	if (clocalnogroup != null && clocalnogroup.length != 0){
		adrs = adrs + "&localnogroup=" + clocalnogroup;
	}
	if (clocalmanage != null && clocalmanage.length != 0){
		adrs = adrs + "&localmanage=" + clocalmanage;
	}
	if (cfldgid != null && cfldgid.length != 0){
		adrs = adrs + "&fldgid=" + cfldgid;
	}
	if (cflduid != null && cflduid.length != 0){
		adrs = adrs + "&flduid=" + cflduid;
	}
	if (ctempno != null && ctempno.length != 0){
		adrs = adrs + "&tempno=" + ctempno;
	}
	if (caddarg != null && caddarg.length != 0){
		adrs = adrs + "&" + caddarg;
    }
	if (inotdel != null && inotdel.length != 0){
		adrs = adrs + "&notdel=" + inotdel;
    }
	if (constnpage != null && constnpage.length != 0){
		adrs = adrs + "&constnpage=" + constnpage;
    }
	if (cntempno != null && cntempno.length != 0){
		adrs = adrs + "&ntempno=" + cntempno;
    }
	if (cmenucolor != null && cmenucolor.length != 0){
		adrs = adrs + "&menucolor=" + cmenucolor;
    }
	if (cimageuse != null && cimageuse.length != 0){
		adrs = adrs + "&imageuse=" + cimageuse;
    }
	if (cusetdisp != null && cusetdisp.length != 0){
		adrs = adrs + "&usetdisp=" + cusetdisp;
    }
	if (cnodispitem != null && cnodispitem.length != 0){
		adrs = adrs + "&nodispitem=" + cnodispitem;
    }
	if (cnewtarget != null && cnewtarget.length != 0){
		adrs = adrs + "&newtarget=" + cnewtarget;
    }
	if (ctempname != null && ctempname.length != 0){
		adrs = adrs + "&tmpnm=" + ctempname;
    }
	if (iadmin != null && iadmin.length != 0){
		adrs = adrs + "&admin=" + iadmin;
    }
/* DNDB450_0015
    if (w == null || w.closed){
*/
		w = window.open(adrs + addarg,wname,"width=" + iw + ",height=" + ih + ",location=0,resizable=yes,scrollbars=yes,status=yes,left=30,top=30");
/* DNDB450_0015
    }
    else{
        w.location.href = adrs;
*/
        w.focus();
/* DNDB450_0015
    }
*/
}
function OpenGroupSelect(cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, caddarg, cmenucolor, cimageuse){
	OpenComSelect("constructgroup", cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, "", caddarg, "", "", "", "", cmenucolor, cimageuse);
}
function OpenGroupsSelect(cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, caddarg, ctempno, inotdel, constnpage, cntempno, cmenucolor, cimageuse, iadmin){
	OpenComSelect("constructgroups", cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, "", caddarg, ctempno, inotdel, constnpage, cntempno, cmenucolor, cimageuse, iadmin);
}
function OpenUserSelect(cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, cflduid, caddarg, cmenucolor, cimageuse, cusetdisp, cnodispitem){
	OpenComSelect("constructuser", cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, cflduid, caddarg, "", "", "", "", cmenucolor, cimageuse, null, cusetdisp, cnodispitem);
}
function OpenUsersSelect(cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, caddarg, ctempno, inotdel, cmenucolor, cimageuse, cusetdisp, cnodispitem, cnewtarget, ctempname){
	OpenComSelect("constructusers", cgiselect, constid, cginame, cpage, igkind, clocalall, clocalnogroup, clocalmanage, cfldgid, "", caddarg, ctempno, inotdel, "", "", cmenucolor, cimageuse, null, cusetdisp, cnodispitem, cnewtarget, ctempname);
}
function CheckAssign(contid, gid, chk)
{
    if (window.parent.header.document.forms[0]) {
		var header = window.parent.header.document.forms[0];
        if (header.gselectkind) {
			for (i=0;i<header.gselectkind.options.length;i++) {
				if (header.gselectkind.options[i].selected) {
					document._form.gselectkind.value = header.gselectkind.options[i].value;
				}
			}
        }
    }
	document._form.CONST_ID.value = contid;
	document._form.constgid.value = gid;
	document._form.constchk.value = chk;
	document._form.constmd.value = 'open';
	document._form.gopen.value = 'open';
	document._form.submit();
}
function DispUserInfo(cginame, id)
{
    window.open(cginame + "?page=constructuserinfo&id=" + id,"constuserinfo","width=500,height=600,location=0,resizable=yes,scrollbars=yes,status=yes,alwaysRaised=yes");
}
function UConLeftGroupCheckBottomList(){
	if (parent == null
	 || parent.leftbottom == null
	 || parent.leftbottom.document == null
	 || parent.leftbottom.document.formdisp == null
	 || parent.leftbottom.document.formdisp.dispgroup == null
	 ){
		return -1;
	}

	return 0;
}
function UConLeftGroupDispSearch()
{
	if (UConLeftGroupCheckBottomList() == 0){
		parent.leftbottom.DispSearch();
		parent.DispLeftTopSearch();
	}
}
function UConLeftGroupDispPGroup()
{
	if (UConLeftGroupCheckBottomList() == 0){
		parent.leftbottom.DispPGroup();
		parent.DispLeftTopPGroup();
	}
}
function UConLeftGroupDispGroup()
{
	if (UConLeftGroupCheckBottomList() == 0){
		parent.leftbottom.DispGroup();
		parent.DispLeftTopGroup();
	}
}
function UConLeftSearchCheckBottomList(){
	if (parent == null
	 || parent.leftbottom == null
	 || parent.leftbottom.document == null
	 || parent.leftbottom.document.formdisp == null
	 || parent.leftbottom.document.formdisp.dispsearch == null
	 ){
		return -1;
	}

	return 0;
}
function UConLeftSearchDispGroup()
{
	if (UConLeftSearchCheckBottomList() == 0){
		parent.leftbottom.DispGroup();
		parent.DispLeftTopGroup();
	}
}
function UConLeftSearchDispPGroup()
{
	if (UConLeftSearchCheckBottomList() == 0){
		parent.leftbottom.DispPGroup();
		parent.DispLeftTopPGroup();
	}
}
function UConRightBottomCheckBottomList(){
	if (parent == null
	 || parent.rightbottomlist == null
	 || parent.rightbottomlist.document == null
	 || parent.rightbottomlist.document._form == null
	 || parent.rightbottomlist.document._form.dispchk == null
	 ){
		return -1;
	}

	return 0;
}
function UConRightBottomSelectDel(){
	var frm;

	if (UConRightBottomCheckBottomList() == 0){
		frm = parent.rightbottomlist.document._form;
		for (i_cnt=0; i_cnt<frm.elements.length; i_cnt++) {
			if (frm.elements[i_cnt].name == 'id'){
				if (frm.elements[i_cnt].checked){
					break;
				}
			}
		}
		if (i_cnt == frm.elements.length){
            // "選択欄をチェックして下さい。"
			alert("Check the select box.");
			return ;
		}
		parent.rightbottomlist.SelectDel();
	}
}
function UConRightBottomFinish(){
	if (UConRightBottomCheckBottomList() == 0){
		frm = parent.rightbottomlist.document._form;
		for (i_cnt=0; i_cnt<frm.elements.length; i_cnt++) {
			if (frm.elements[i_cnt].name == 'id'){
				if (frm.elements[i_cnt].checked){
					break;
				}
			}
		}
		if (i_cnt == frm.elements.length){
            // "選択欄をチェックして下さい。"
			alert("Check the select box.");
			return ;
		}
		parent.rightbottomlist.Finish();
	}
}
function UConRightTopCheckTopList(){
	if (parent == null
	 || parent.righttoplist == null
	 || parent.righttoplist.document == null
	 || parent.righttoplist.document._form == null
	 || parent.righttoplist.document._form.dispchk == null
	 ){
		return -1;
	}

	return 0;
}
function UConRightTopSelectAdd(){
	var frm;

	if (UConRightTopCheckTopList() == 0){
		frm = parent.righttoplist.document._form;
		for (i_cnt=0; i_cnt<frm.elements.length; i_cnt++) {
			if (frm.elements[i_cnt].checked){
				break;
			}
		}
		if (i_cnt == frm.elements.length){
            // "選択欄をチェックして下さい。"
			alert("Check the select box.");
			return ;
		}

		if (parent.rightbottomlist == null
		 || parent.rightbottomlist.document == null
		 || parent.rightbottomlist.document._form == null
		 || parent.rightbottomlist.document._form.dispchk == null
		 ){
/*
選択リストが完全に表示されるまえに追加処理を行うと選択リストのリフレッシュに失敗する可能性があるため。
*/
			return ;
		}

		parent.righttoplist.SelectAdd();
	}
}
//--->
