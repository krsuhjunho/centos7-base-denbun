#!/bin/csh
#
# check arguments
#
if ($#argv < 1) then
        echo usage : dnwmldwlcomp.sh targetdir zipfilename
        exit 200
endif
#
# initialize value
#
set target=$1
set zipfile=$2
#
# zip
#
cd $target
cd ..
/usr/bin/zip -r $zipfile mail
set ret=$status
if ($ret != 0) then
        exit 201
endif
#
# end
#
exit 0

