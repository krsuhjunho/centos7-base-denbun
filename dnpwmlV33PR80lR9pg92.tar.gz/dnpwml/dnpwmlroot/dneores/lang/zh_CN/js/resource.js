//var neo = {};
(function($) {
//neo.Resource = {};
/**
 * Ajax通信の文言
 *
 * @class Ajax通信の文言
 */
DNNEO.neo.Resource.ajax = {
    '400_errorMessage' : 'W:也许此处理已经完成，也许可能没依据操作程序进行。 请停止操作，从最初开始重新操作。',
// ブラウザが勝手に認証ダイアログを表示するので403に統括    "401_errorMessage" : "W:認証できませんでした。再度ログインしてください。",
    '403_errorMessage' : 'W:不能访问被要求的处理。<br/>也许发生了权限的更改或是有可能链接断开了。请停止操作，从最初开始重新操作。',
    '404_errorMessage' : 'URL可能有错误。',
    '408_errorMessage' : 'W:数据库服务器正处于拥挤中。请稍候片刻后再次实行。',
    '409_errorMessage' : '数据库处于停止，或是没有操作领域的访问权限等，服务器发生了异常。请向系统管理员咨询。',

    '500_errorMessage' : '服务器发生了异常。请向系统管理员咨询。',

    // Webサーバーの接続制限に達した
    '503_errorMessage' : 'W:服务器繁忙。请稍候片刻后再次实行。',

    '504_errorMessage' : '服务器出现超时。',

    // Webサーバーが停止しているときに発生
    'errorMessage' : '有可能是服务器停止了或是网络正处于拥挤状态。[{{status}}]'
};
})(jQuery);
/// <reference path="/njres/js/extlibs/jquery-1.6.3-vsdoc.js" />
/// <reference path="/njres/js/extlibs/jquery-ui-1.8.16.custom.js" />

//var desknets = {};

/**
 *  共通系文言
 *
 * @class 共通系文言
 */
desknets.Resource = {
      'code': 'zh_CN'
/*
ダイアログのタイトル
*/
    , 'errorDefaultTitle'   : '错误'
    , 'warnDefaultTitle'    : '警告'
    , 'confirmDefaultTitle' : '确认'
    , 'messageDefaultTitle' : '信息'

/*
ダイアログのボタン
*/
    , 'CloseButtonLabel': '关闭' // 参照系ダイアログの確認ボタン
    , 'OKButtonLabel': 'OK' // 選択、変更系ダイアログの決定ボタン
    , 'CancelButtonLabel': '取消' // 選択、変更系ダイアログの取り消しボタン
    , 'ConfOKButtonLabel': '是' // 確認ダイアログの肯定ボタン
    , 'ConfCancelButtonLabel': '否' // 確認ダイアログの否定ボタン

/**
 よく使う文言
 */
   , 'closeLabel': '关闭'
   , 'abortLabel' : '停止'
   , 'attachLabel':'添加'

/**
 添付
 */
   , 'attachTitle': '添加文件'
};

(function($) {
/**
 *  メッセージリソース
 *  記述方法
 *  '機能IDXXX' : 'Level: XXXXXXXXXXXXXXXXXXXXXXXXXXX'
 *  機能ID＝sch,todo等
 *  レベル＝E:エラー,W:警告,M:メッセージ
 *
 * @class desknets.Resuorc.Message
 */
desknets.Resource.Message = {
//-----------------------------------------------------------
// 共通
//-----------------------------------------------------------
    // , 'com_copy_attachsize_over': 'M:由于添加文件的大小超出了限制，所以没能添加。'
    // , 'com_copy_attachs_missing': 'M:添加文件的复制失败了。<br />有可能是被人为或是反病毒等外部程序给删除了。请再次选择添加文件。'
//-----------------------------------------------------------
// 検索共通
//-----------------------------------------------------------
      'com_attachlist_confirm_one': '解除所选择的文件。确定吗？'
    , 'com_attachlist_confirm_all': '解除所有文件。确定吗？'
//-----------------------------------------------------------
// 添付ファイル関連
//-----------------------------------------------------------
    , 'att_total_size_over':     'W:超出了可以加载的合计大小。合计大小({{total}})／上传可能大小({{limit}})'
    , 'att_filesize_zero':       'W:不能上传0字节的文件。({{filenames}})'
    , 'att_overlap_file_single': '文件名有重复。要盖写吗？({{filenames}})'
    , 'att_overlap_file_multi':  '文件名重复的文件有{{num}}个。要盖写吗？({{filenames}})'
    , 'att_other_files':         '．．．其他({{num}}文件)'
    , 'att_drop_max_over':       'W:超出了拖放可能的文件数。已指定了{{num}}个。最大为{{max}}个。'
    , 'att_illegal_filename':    'W:被指定的文件的文件名无效。'
    , 'att_file_select':         'W:请指定加载文件。'
    , 'att_detach_all':          '解除所有文件。确定吗？'
    , 'att_close_dialog':        '指定的文件没被加载。确定吗？'
    , 'att_close_clear':         '是否取消已上传的文件？'
    , 'att_del_confirm':         '解除「{{filenames}}」。确定吗？'
    , 'att_network_err':         '服务器的连接失败了。'
    , 'att_upload_now':          '正在加载中。'
    , 'att_flash_reject_cancel_single': 'W:盖写的文件「{{filenames}}」没能被消除。'
    , 'att_flash_reject_cancel_multi' : 'W:盖写的文件「{{filenames}}」其他({{num}}文件)没能被消除。'
    , 'att_flash_reject_delete'       : 'W:不能删除已盖写的文件「{{filenames}}」。'
};

})(jQuery);
/// <reference path="/njres/lang/ja_JP/js/resource.js.src/002resource.js" />

(function($) {
/**
 * 添付ファイル関連
 */
desknets.Resource.attach = {
    // 処理中表示で100%の場合、プログレスバーに表示する文言
  'saveMsg': '<span class="co-pop-tp-file-save">导入中</span>'
  , 'saveMsgIE': '导入中'
    // IEでアップロード中にプログレスバーへ表示しておく文言
  , 'uploadMsg': '导入中'
    // ドロップ可能な最大数を表示
  , 'dropMaxMsg': '是否将邮件文件拖放（最多{{maxdrop}}个）在此处'
    // Flashに渡すラベル
  , 'saveLabel': '保存中...'
  , 'deleteLabel': '删除'
  , 'deleteAllLabel': '解除所有选择'
  , 'flashChangeMsg': '<p class="co-msg">*&nbsp;If you want to use the attachment button which has the  multiple attachments feature, please switch the upload mode.-&gt; <a href="#" class="co-pop-tp-flash-mode-change-btn">Switch</a></p>'
  , 'flashChangeMsgNormal': '<p class="co-msg">*&nbsp;If the attachment button does not work correctly, please switch the upload mode. -&gt;<a href="#" class="co-pop-tp-flash-mode-change-btn">Switch</a></p>'
  , 'flashDownloadMsg': '<p class="co-msg"><FONT color="red">* &nbsp;FlashPlaye is not installed. Please install FlashPlayer.</FONT><a href="http://www.adobe.com/go/getflashplayer" target="flash"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" /></a></p>'

  , 'cancelAllUploadLabel': '停止全部导入'
  , 'dropHereLabel': '将邮件文件拖放在此处、或是'
  , 'clickFileSelectLabel': '请点击并选择邮件文件。'
  , 'selectFromButtonLabel': '请从选择键里选择邮件文件。'
  , 'attachLabel': '选择'
  , 'releaseLabel': '解除选择'
  , 'deleteLabel': '删除'
  , 'fileUploadLabel': '导入邮件'
};

})(jQuery);
