/*
 * desknet's 
 * http://www.desknets.com/
 * Copyright (C) NEOJAPAN,Inc. All Rights Reserved.
 * 本製品は日本国著作権法および国際条約により保護されています。 
 * 本製品の全部または一部を無断で複製したり、無断で複製物を頒 
 * 布すると著作権の侵害となりますのでご注意ください。 
 */
neo.mobile.dialog.Resource={labelOK:"O K",labelCancel:unescape("%u30AD%u30E3%u30F3%u30BB%u30EB"),titleDefaultAlert:unescape("%u8B66%u544A"),titleDefaultConfirm:unescape("%u78BA%u8A8D"),};