//var neo = {};
(function($) {
//neo.Resource = {};
/**
 * Ajax通信の文言
 *
 * @class Ajax通信の文言
 */
DNNEO.neo.Resource.ajax = {
    '400_errorMessage' : 'W:This process has been done or is doing with wrong procedure. Stop the process and retry it.',
// ブラウザが勝手に認証ダイアログを表示するので403に統括    "401_errorMessage" : "W:Failed to authenticate. Please login again.",
    '403_errorMessage' : 'W:Cannot access the requested operation.<br/>The session may has expired or privilege changes may occurred. Please interrupting the work, and try again from the beginning.',
    '404_errorMessage' : 'The URL may be incorrect.',
    '408_errorMessage' : 'W:The database is busy. Please wait for a while and try it again.',
    '409_errorMessage' : 'An error, such as the database is stopped or there is no access right to the work area occurred on the server. Please contact your administrator.',

    '500_errorMessage' : 'An error has occurred on the server. Please ask your administrator.',

    // Webサーバーの接続制限に達した
    '503_errorMessage' : 'W:The server is busy. Please wait for a while and try it later on.',

    '504_errorMessage' : 'Timeout has occurred on the server.',

    // Webサーバーが停止しているときに発生
    'errorMessage' : 'The server may be stopped or network may be busy. [{{status}}]'
};
})(jQuery);
/// <reference path="/njres/js/extlibs/jquery-1.6.3-vsdoc.js" />
/// <reference path="/njres/js/extlibs/jquery-ui-1.8.16.custom.js" />

//var desknets = {};

/**
 *  共通系文言
 *
 * @class 共通系文言
 */
desknets.Resource = {
      'code': 'en_US'
/*
ダイアログのタイトル
*/
    , 'errorDefaultTitle'   : 'Error'
    , 'warnDefaultTitle'    : 'Warning'
    , 'confirmDefaultTitle' : 'Confirmation'
    , 'messageDefaultTitle' : 'Message'

/*
ダイアログのボタン
*/
    , 'CloseButtonLabel': 'Close' // 参照系ダイアログの確認ボタン
    , 'OKButtonLabel': 'OK' // 選択、変更系ダイアログの決定ボタン
    , 'CancelButtonLabel': 'Cancel' // 選択、変更系ダイアログの取り消しボタン
    , 'ConfOKButtonLabel': 'Yes' // 確認ダイアログの肯定ボタン
    , 'ConfCancelButtonLabel': 'No' // 確認ダイアログの否定ボタン

/**
 よく使う文言
 */
   , 'closeLabel': 'Close'
   , 'abortLabel' : 'Stop'
   , 'attachLabel':'Attach'

/**
 添付
 */
   , 'attachTitle': 'Attachment File'
};

(function($) {
/**
 *  メッセージリソース
 *  記述方法
 *  '機能IDXXX' : 'Level: XXXXXXXXXXXXXXXXXXXXXXXXXXX'
 *  機能ID＝sch,todo等
 *  レベル＝E:エラー,W:警告,M:メッセージ
 *
 * @class desknets.Resuorc.Message
 */
desknets.Resource.Message = {
//-----------------------------------------------------------
// 共通
//-----------------------------------------------------------
    // , 'com_copy_attachsize_over': 'M:Since the size of the attachment exceeds the limit, the attachment file is not copied.'
    // , 'com_copy_attachs_missing': 'M:Failed to copy the attached file.<br />The file may have been deleted by a user or the external program such as anti-virus program. Please select the attachment file again.'
//-----------------------------------------------------------
// 検索共通
//-----------------------------------------------------------
      'com_attachlist_confirm_one': 'The selected files will be unselected. Are you sure?'
    , 'com_attachlist_confirm_all': 'All files will be cancelled. Are you sure?'
//-----------------------------------------------------------
// 添付ファイル関連
//-----------------------------------------------------------
    , 'att_total_size_over':     'W:Total size of files exceeds the limit. Total Size ({{total}}) / Max Size ({{limit}})'
    , 'att_filesize_zero':       'W:You cannot upload 0 byte file.({{filenames}})'
    , 'att_overlap_file_single': 'The file name is duplicated. Do you want to overwrite it? ({{filenames}})'
    , 'att_overlap_file_multi':  'There are {{num}} files whose name is a duplicate. Do you want to overwrite it? ({{filenames}})'
    , 'att_other_files':         '...Other ({{num}} Files)'
    , 'att_drop_max_over':       'W:The number of files to be dropped exceeds the limit. {{num}} files were selected. The limit is {{max}} files.'
    , 'att_illegal_filename':    'W:The file name is invalid.'
    , 'att_file_select':         'W:Please select file you want to upload.'
    , 'att_detach_all':          'All files will be cancelled. Are you sure?'
    , 'att_close_dialog':        'The files you selected will not be uploaded. Are you sure?'
    , 'att_close_clear':         'Do you want to cancel file you uploaded?'
    , 'att_del_confirm':         '"{{filenames}}" will be cancelled. Are you sure?'
    , 'att_network_err':         'Failed to connect to the server.'
    , 'att_upload_now':          'Uploading now.'
    , 'att_flash_reject_cancel_single': 'W:The overwritten file "{{filenames}}" could not be cancelled.'
    , 'att_flash_reject_cancel_multi' : 'W:The overwritten file "{{filenames}}" and other ({{num}} files) could not be cancelled.'
    , 'att_flash_reject_delete'       : 'W:The overwritten file "{{filenames}}" could not be deleted.'
};

})(jQuery);
/// <reference path="/njres/lang/ja_JP/js/resource.js.src/002resource.js" />

(function($) {
/**
 * 添付ファイル関連
 */
desknets.Resource.attach = {
    // 処理中表示で100%の場合、プログレスバーに表示する文言
  'saveMsg': '<span class="co-pop-tp-file-save">Saving...</span>'
  , 'saveMsgIE': 'Saving...'
    // IEでアップロード中にプログレスバーへ表示しておく文言
  , 'uploadMsg': 'Saving...'
    // ドロップ可能な最大数を表示
  , 'dropMaxMsg': 'Drop files (max. {{maxdrop}} files) or,'
    // Flashに渡すラベル
  , 'saveLabel': 'Saving...'
  , 'deleteLabel': 'Cancel'
  , 'deleteAllLabel': 'Unselect All'
  , 'flashChangeMsg': '<p class="co-msg">*&nbsp;If you want to use the attachment button which has the  multiple attachments feature, please switch the upload mode.-&gt; <a href="#" class="co-pop-tp-flash-mode-change-btn">Switch</a></p>'
  , 'flashChangeMsgNormal': '<p class="co-msg">*&nbsp;If the attachment button does not work correctly, please switch the upload mode. -&gt;<a href="#" class="co-pop-tp-flash-mode-change-btn">Switch</a></p>'
  , 'flashDownloadMsg': '<p class="co-msg"><FONT color="red">* &nbsp;FlashPlaye is not installed. Please install FlashPlayer.</FONT><a href="http://www.adobe.com/go/getflashplayer" target="flash"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" /></a></p>'

  , 'cancelAllUploadLabel': 'Stop All Uploads'
  , 'dropHereLabel': 'Drop files here or '
  , 'clickFileSelectLabel': 'click to select files.'
  , 'selectFromButtonLabel': 'select files by using the Attach button.'
  , 'attachLabel': 'Attach'
  , 'releaseLabel': 'Unselect'
  , 'deleteLabel': 'Delete'
  , 'fileUploadLabel': 'Upload Files'
};

})(jQuery);
