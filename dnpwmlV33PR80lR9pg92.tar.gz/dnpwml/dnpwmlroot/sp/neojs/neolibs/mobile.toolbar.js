(function($){
/**
 * ツールバー
 *
 * @class
 */
$.widget("mobile.toolbar", $.mobile.widget, {
	_currTop: 0, // 現在位置
	_toTop: 0, // 移動先位置
	_isEnabled: false, // 有効かどうか
	_isPageActive: false, // ページが有効かどうか
	_onScroll: null, // スクロールイベント関数参照
	_onShow: null, // 表示イベント関数参照
	_onHide: null, // 非表示イベント関数参照
	_cssTransform: "-webkit-transform", // CSS表示変換
	_cssTransition: "-webkit-transition", // CSS遷移
	_isAnimating: false, // アニメーション中か

	options: {
		top: null, bottom: null, // 位置
		minTop: 0, maxTop: 10000, // 移動範囲
		effect: "slide", duration: 200, // 移動秒数
		enable: true,
	},

	/**
	 * ウィジェットを作成する。
	 */
	_create: function() {
		var self = this;
		this.element.css("position", "absolute");
		this._onScroll = function(event) { 
			setTimeout(function(){ self._animatePosition(); }, 0);
		};
		this._onShow = function(event) { 
			self._isPageActive = true;
			self._enable();
		};
		this._onHide = function(event) {
			self._isPageActive = false;
			self._disable();
		};
		this._initState();
		this._initPageElement();
	},

	/**
	 * 有効に設定する。
	 */
	enable: function() {
		this._isEnabled = true;
		this._enable();
	},

	/**
	 * 有効に設定する。
	 */
	disable: function() {
		this._isEnabled = false;
		this._disable();
	},

	/**
	 * ウィジェットを破棄する。
	 */
	destroy: function() {
		this.disable();
		var pageElement = this.element.closest("[data-role='page']");
		pageElement.unbind("pageshow", this._onShow);
		pageElement.unbind("pagehide", this._onHide);
	},

	/**
	 * ページ要素を初期化する。
	 */
	_initPageElement: function() {
		var self = this;
		var pageElement = this.element.closest("[data-role='page']");
		if (pageElement.hasClass("ui-page-active")) {
			this.enable();
		}
		pageElement.bind("pageshow", this._onShow);
		pageElement.bind("pagehide", this._onHide);
	},

	/**
	 * 状態を初期化する。
	 */
	_initState: function() {
		if (this.options.enable) {
			this.enable();
		} else {
			this.disable();
		}
	},

	/**
	 * 位置を初期化する。
	 */
	_initPosition: function() {
		this._updateToPosition();
		this._currTop = this._toTop;
		this.element.css("top", this._toTop + "px");
	},

	/**
	 * ウィジェットを有効化する。
	 */
	_enable: function() {
		if (!this._isEnabled || !this._isPageActive) {
			return;
		}
		if (!this.element.hasClass("ui-toolbar-disabled")) {
			return 
		}

		this.element.removeClass("ui-disabled ui-toolbar-disabled");
		this._initPosition();
		$(window).bind("scroll", this._onScroll);
		$(window).bind("resize", this._onScroll);
	},

	/**
	 * ウィジェットを無効化する。
	 */
	_disable: function() {
		if (this._isEnabled && this._isPageActive) {
			return;
		}
		if (this.element.hasClass("ui-toolbar-disabled")) {
			return 
		}

		this.element.addClass("ui-disabled ui-toolbar-disabled");
		$(window).unbind("scroll", this._onScroll);
		$(window).unbind("resize", this._onScroll);
	},

	/**
	 * 位置のアニメーションを行う。
	 */
	_animatePosition: function() {
		var self = this;
		this._updateToPosition();
		if (this._currTop != this._toTop && !this._isAnimating){
			this._isAnimating = true;
			this._beginToAnimatePosition();
		}
	},

	/**
	 * 位置のアニメーションを開始する。
	 */
	_beginToAnimatePosition: function() {
		var fromY = this._currTop;
		this.element.css("top",  this._toTop + "px");
		this._currTop = this._toTop;

		if (this.options.effect == "slide") {
			this._beginToSlide(fromY);
		} else {
			this._endToAnimatePosition();
		}
	},

	/**
	 * 平行移動アニメーションを開始する。
	 */
	_beginToSlide: function(fromY) {
		var self = this;
		var relY = fromY - this._toTop;
		var duration = Math.floor((Math.abs(relY) * this.options.duration) / 100);
		// 初期状態設定
		this.element.css(this._cssTransition, this._cssTransform);
		this.element.css(this._cssTransform, "translate(0, " + relY + "px)");

		// アニメーション開始
		setTimeout(function() {
			self.element.css(self._cssTransition, self._cssTransform + " " + duration + "ms linear");
			self.element.css(self._cssTransform, "translate(0, 0)");
		}, 1);
		// アニメーション終了
		setTimeout(function() {
			self._endToAnimatePosition();
		}, duration);
	},

	/**
	 * 位置のアニメーションを終了する。
	 */
	_endToAnimatePosition: function() {
		this._isAnimating = false;
		this._animatePosition();
	},

	/**
	 * 移動先の位置を更新する。
	 */
	_updateToPosition: function() {
		var top = $(window).scrollTop();
		var bottom = top + window.innerHeight - this.element.outerHeight();
		this._updateToPositionProperties("_toTop", "top", top, 1);
		this._updateToPositionProperties("_toTop", "bottom", bottom, -1);
		this._toTop = this._getInRange(this._toTop, this.options.minTop, this.options.maxTop);
	},

	/**
	 * 移動先の位置プロパティを更新する。
	 *
	 * @param {String} propName    [IN]:プロパティ名
	 * @param {Number} optionName  [IN]:オプション名
	 * @param {Number} baseValue   [IN]:基本位置
	 * @param {Number} sign        [IN]:方向(1/-1)
	 */
	_updateToPositionProperties: function(propName, optionName, baseValue, sign) {
		if (this.options[optionName] != null) {
			this[propName] = baseValue + this.options[optionName] * sign;
		}
	},

	/**
	 * 値を範囲内にする。
	 *
	 * @param {Number} value [IN]:値
	 * @param {Number} min   [IN]:最小値
	 * @param {Number} max   [IN]:最大値
	 * @return {Number} 値
	 */
	_getInRange: function(value, min, max) {
		return Math.min(max, Math.max(min, value));
	},
}); 
})(jQuery);